'use client'

import { useEffect, useRef, useState } from 'react'

interface UseRevealOptions {
threshold?: number
rootMargin?: string
triggerOnce?: boolean
}

export function useReveal({
threshold = 0.1,
rootMargin = '0px',
triggerOnce = true,
}: UseRevealOptions = {}) {
const ref = useRef<HTMLElement | null>(null)
const [revealed, setRevealed] = useState(false)

useEffect(() => {
const element = ref.current

if (!element) return

const observer = new IntersectionObserver(
  ([entry]) => {
    if (entry.isIntersecting) {
      setRevealed(true)

      if (triggerOnce) {
        observer.unobserve(entry.target)
      }
    } else if (!triggerOnce) {
      setRevealed(false)
    }
  },
  {
    threshold,
    rootMargin,
  }
)

observer.observe(element)

return () => {
  observer.disconnect()
}

}, [threshold, rootMargin, triggerOnce])

return { ref, revealed }
}